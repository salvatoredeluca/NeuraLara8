#ifndef DDS_PUBLISHER_HPP
#define DDS_PUBLISHER_HPP

#include <fastdds/dds/domain/DomainParticipant.hpp>
#include <fastdds/dds/domain/DomainParticipant.hpp>
#include <fastdds/dds/domain/DomainParticipantFactory.hpp>
#include <fastdds/dds/domain/qos/DomainParticipantFactoryQos.hpp>
#include <fastdds/dds/domain/qos/DomainParticipantQos.hpp>
#include <fastdds/dds/publisher/DataWriter.hpp>
#include <fastdds/dds/publisher/DataWriterListener.hpp>
#include <fastdds/dds/publisher/Publisher.hpp>
#include <fastdds/dds/publisher/qos/DataWriterQos.hpp>
#include <fastdds/dds/publisher/qos/PublisherQos.hpp>
#include <fastdds/dds/topic/TypeSupport.hpp>

#include <neura_dds_utils/traces.hpp>

using namespace eprosima::fastdds::dds;

namespace neura_dds_wrapper
{
struct QosConfig
{
    PublisherQos publisher;
    TopicQos topic;
    DataWriterQos writer;
};

class DDSPubListener : public DataWriterListener
{
   public:
    DDSPubListener();
    ~DDSPubListener() override;
    void on_publication_matched(DataWriter* writer,
                                const PublicationMatchedStatus& info) override;
    inline bool hasListener()
    {
        return /* waitForListener || */ firstConnected_ || matched_ > 0;
    };
    int matched_;
    bool firstConnected_;
};

template <class MsgType, class PubSubType>
class DDSPublisher
{
   public:
    MsgType reply;
    TypeSupport typeSupport;
    Topic* pTopic;
    DataWriter* pWriter;
    Publisher* pPublisher;
    DDSPublisher()
        : reply(),
          typeSupport(new PubSubType()),
          pTopic(nullptr),
          pWriter(nullptr),
          pPublisher(nullptr)
    {
        TRACE(COMM, "init publisher")
    }     
    ~DDSPublisher();
    inline void publish() { pWriter->write(&reply); };
    // static bool try_delete_publisher(DomainParticipant* pParticipant,
    // DDSPublisher* pPublisher);
    // std::function<void,MsgType&> updateBufferCallback;
};

// template <class MsgType>
// bool DDSPublisher<MsgType>::try_delete_publisher(
//     DomainParticipant* pParticipant, DDSPublisher* pPublisher)
// {
//     if (!pParticipant)
//     {
//         throw NullParticipantException();
//     }
// }

class DDSPublisherFactory
{
   public:
    DDSPublisherFactory(DomainParticipant* pParticipant,
                        DDSPubListener* pListener);
    template <class MsgType, class PubSubType>
    DDSPublisher<MsgType, PubSubType>* createDDSPublisher(
        std::string topicName);

   private:
    struct QosConfig QosConfig_;
    DomainParticipant* pParticipant_;
    DDSPubListener* pListener_;
};

template <class MsgType, class PubSubType>
DDSPublisher<MsgType, PubSubType>* DDSPublisherFactory::createDDSPublisher(
    std::string topicName)
{
    DDSPublisher<MsgType, PubSubType>* pPub =
        new DDSPublisher<MsgType, PubSubType>;
    pPub->pPublisher =
        pParticipant_->create_publisher(QosConfig_.publisher, nullptr);
    if (pPub->pPublisher == nullptr)
    {
        TRACE(COMM, "Creating publisher failed for topic " << topicName)
        return nullptr;
    }
    ReturnCode_t ret = pPub->typeSupport.register_type(pParticipant_);
    if (ret != ReturnCode_t::RETCODE_OK)
    {
        TRACE(COMM, "Type registering failed for "
                        << pPub->typeSupport.get_type_name()
                        << " reason: " << ret())
        return nullptr;
    }
    // TODO eventually wrong QoS to communicate with client
    pPub->pTopic = pParticipant_->create_topic(
        std::string(topicName), pPub->typeSupport.get_type_name(),
        QosConfig_.topic);
    if (pPub->pTopic == nullptr)
    {
        TRACE(COMM, "Topic object could not be created for " << topicName)
        return nullptr;
    }
    ResourceLimitsQosPolicy resource_limits;
    //The ResourceLimitsQosPolicy is default constructed with max_samples = 5000
    //Change max_samples to 200
    resource_limits.max_samples = 200;
    //The ResourceLimitsQosPolicy is default constructed with max_instances = 10
    //Change max_instances to 20
    resource_limits.max_instances = 20;
    //The ResourceLimitsQosPolicy is default constructed with max_samples_per_instance = 400
    //Change max_samples_per_instance to 100 as it must be lower than max_samples
    resource_limits.max_samples_per_instance = 100;
    //The ResourceLimitsQosPolicy is default constructed with allocated_samples = 100
    //Change allocated_samples to 50
    resource_limits.allocated_samples = 50;
    DataWriterQos writeQos;
    writeQos.resource_limits(resource_limits); //TODO Warning is still persistent

    pPub->pWriter = pPub->pPublisher->create_datawriter(
        pPub->pTopic, writeQos, pListener_);
    if (pPub->pWriter == nullptr)
    {
        TRACE(COMM, "Writer object could not be created for " << topicName);    
        return nullptr;
    }
    TRACE(COMM, "Publisher created for topic=" << topicName)

    return pPub;
}

}  // namespace neura_dds_wrapper
#endif
