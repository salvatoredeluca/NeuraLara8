#ifndef DDS_PARTICIPANT_HPP
#define DDS_PARTICIPANT_HPP

#include <fastrtps/transport/UDPv4TransportDescriptor.h>

#include <fastdds/dds/domain/DomainParticipant.hpp>
#include <fastdds/dds/domain/DomainParticipantFactory.hpp>
#include <memory>
#include <string>

//#include <fastdds/rtps/attributes/ThreadSettings.hpp>

using namespace eprosima::fastdds::rtps;
using namespace eprosima::fastdds::dds;

namespace neura_dds_wrapper {
/**
 * @brief Creates different variants of DDS participators, both IP and shared
 * memory based
 */
class DDSParticipantFactory {
 public:
  DDSParticipantFactory();
  ~DDSParticipantFactory();
  /**
   * @brief Creates a non-blocking UDP and Shared Memory participator with given
   * domain ID number
   */
  DomainParticipant* createParticipant(unsigned int domain_id);
  /**
   * @brief Creates a non-blocking UDP and Shared Memory participator
   */
  DomainParticipant* createParticipant(std::array<uint8_t, 4> host_ip_address);
  /**
   * @brief Creates a universal UDP and Shared Memory participator with
   * default settings of Fast-DDS
   */
  DomainParticipant* createParticipant();
  /**
   * @brief Creates a Shared Memory only participator for interprocess
   * communication on a single host
   */
  DomainParticipant* createSharedMemParticipant();

  /**
   * @brief Creates a default UDP participator for communication between
   * localhost and '192.168.2.13'
   */
  DomainParticipant* createDefaultUdpParticipant();

  /**
   * @brief TODO
   */
  DomainParticipant* createServerParticipant(
      std::array<uint8_t, 4> listening_ip_address,
      uint16_t listening_port = 5998);

  DomainParticipant* createClientParticipant(
      std::array<uint8_t, 4> host_ip_address,
      std::array<uint8_t, 4> server_ip_address, uint16_t target_port = 5998);

 private:
  std::shared_ptr<UDPv4TransportDescriptor> makeNonBlockingUDPTransport();
  // TODO add domain name to this default QoS
  DomainParticipantQos default_qos_;
  // const char* guid_prefix_;
  std::string ipv4_array2str(std::array<uint8_t, 4> ipv4_octet_array);
};

}  // namespace neura_dds_wrapper

#endif
