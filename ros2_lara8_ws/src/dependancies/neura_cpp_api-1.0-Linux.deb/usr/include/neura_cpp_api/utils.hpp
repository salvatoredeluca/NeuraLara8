#ifndef NRTI_UTILS_HPP
#define NRTI_UTILS_HPP

#include <chrono>
#include <string>
#include <vector>

using namespace std::chrono;

namespace neura
{
namespace utils
{
//void printTuple(const std::array& in, std::string label);
void printState(const std::vector<double>& pos, 
   const std::vector<double>&vel,
   const std::vector<double>&accel,
   double& timestamp);


class CycleTimer
{
   public:
    CycleTimer(){};
    ~CycleTimer(){};
    void take();    
    void processTimestamps();
   private:
    std::vector<time_point<high_resolution_clock, duration<double, std::micro>>> timestamps;
   
   std::vector<duration<double, std::micro>> convertToDurations(const std::vector<time_point<high_resolution_clock, duration<double, std::micro>>>& timestamps);
   void processDurations(const std::vector<std::chrono::duration<double, std::micro>>& durations);

};

}  // namespace utils

}  // namespace nrti

#endif
