#ifndef DDS_UTILS_TRACES_HPP
#define DDS_UTILS_TRACES_HPP

// CATEGORIES: ERROR, APP, CLIENT, QUEUE, INPUT, COMM
#ifdef NRTI_TRACE
#include <iostream>
#define TRACE(CATEGORY, TEXT) std::cout << "[NRTI][" << #CATEGORY << "] " << TEXT << std::endl;
//#define nrti_trace(std::string category, ...) { std::cout << "[NRTI][" << category << "] " << stream << std::endl;
#else
#define TRACE(CATEGORY, TEXT) {}
//#define nrti_trace(std::string category, ...stream) {}
#endif

#endif