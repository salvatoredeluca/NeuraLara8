#ifndef NRTI_ROBOT_HPP
#define NRTI_ROBOT_HPP

#include <array>
#include <exception>
#include <functional>
#include <memory>
#include <thread>
#include <vector>

namespace neura
{
class Robot
{
   public:
    /**
     * @brief Constructs a an interface object ready to communicate with a robot
     * specified by its serial number
     * @param robot_num the serial number (from integer digits only) of the
     * target robot
     *
     * Multiple instance will use the same communication client in the
     * background
     */
    Robot(unsigned int robot_num = 0);

    /**
     *  @brief The last destructor of multiple Robot() instances will stop any
     * communication within the program */
    ~Robot();

    /**
     * @brief Function to Power On the robot. The function would only work when the robot is in external mode. External Mode can be triggered through GUI.
     * 
     * @return true Power On command is successful
     * @return false Power On command is unsuccessful
    */
    bool powerON();

    /**
     * @brief Function to Power Off the robot. The function would only work when the robot is in external mode. External Mode can be triggered through GUI.
     * PowerOn must be called before using this function from the client, otherwise robot will not power off.
     * 
     * @return true Power Off command is successful
     * @return false Power Off command is unsuccessful
    */
    bool powerOFF();

    /**
     * @brief This function returns the last received machine state if available.
     * @param status_word is a target uint64 variable. The first 7 bits of this status word represent various machine states, where each 
     * bit is either 0 or 1 depending on the specific condition of the machine.
     * The first 7 bits are described as follows:
     * - **Bit 0 (ROB ON)**: 0 = Simulation mode, 1 = Real mode.
     * - **Bit 1 (NO MOTION)**: 0 = Motion occurring, 1 = No motion.
     * - **Bit 2 (ZeroG ON)**: 0 = Zero gravity off, 1 = Zero gravity on.
     * - **Bit 3 (Singularity)**: 0 = No singularity, 1 = Singularity present.
     * - **Bit 4 (Ext/Int)**: 0 = Internal mode, 1 = External mode.
     * - **Bit 5 (Error)**: No error, 1 = Error occurred.
     * - **Bit 6 (Collision detected)**: 0 = No collision, 1 = Collision detected.
     * - **Bit 7 (REAL/SIM)**: 0 = Simulation, 1 = Real
     * - **Bit 8 - 23**: Reserved
     * - **Bit 24 - (Cart/Joint)**: 0 = Joint, 1 = Cartesian
     * - **Bit 25 - (Pos/Torque)**: 0 = Position, 1 = Torque
     * - **Bit 28 - 31 (DOF Information)**: Convert binary to decimal to get DOF value
     * @return True if the status word has been successfully retrieved. False if the buffer is empty.
     *
     * Only if at least one value has been received since the instantiation of
     * this class - the target will be overwritten with the last value, and the
     * function will return true.
     */
    bool getLastMachineState(uint64_t& status_word);

    /**
     * @brief Reports the last received values for angle position, velocity and
     * accelration of each joint drive. This function returns the last received values for the angular position, 
     * velocity, and acceleration of each joint in the robot. The length of the 
     * vectors depends on the robot's degrees of freedom (DOF) (6 or 7).
     * @param position is the position vector of joint positions
     * A vector containing the angular positions of each joint (in radians).
     * @param velocity A vector containing the angular velocities of each joint (in radians per second).
     * @param torques A vector containing the joint torques of each joint (in Nm).
     * @param timestamp A variable representing the unix time since the robot interface started publishing data.
     * @return true if values have been received since instantiation, else false
     * 
     * When returning false, client-side buffer is empty and no data has been recieved.
     */
    bool getLastJointStates(std::vector<double>& position,
                            std::vector<double>& velocity,
                            std::vector<double>& torques,
                            double& timestamp);

    /**
     *  @brief Retrieves the most recent Cartesian state of the Tool Center Point (TCP).
     * 
     * This function returns the last received values for the position, orientation, 
     * translational velocity, and rotational velocity of the robot's Tool Center Point (TCP).
     * The length of the vectors is typically 3 for position, translational velocity, 
     * and rotational velocity and 4 for quaternion orientation (qw, qx, qy, qz).
     * 
     * @param position A vector containing the Cartesian position of the TCP (x, y, z in meters).
     * @param quaternion A vector representing the orientation of the TCP in quaternion form (qw, qx, qy, qz).
     * @param trans_vel A vector containing the translational velocity of the TCP (in meters per second).
     * @param rot_vel A vector containing the rotational velocity of the TCP (omegax, omegay, omegaz in radians per second).
     * @param timestamp A variable representing the unix time since the robot interface started publishing data.
     * @return True if values have been successfully received since the function was called. 
     * False if the client-side buffer is empty and no data has been received.  
     */ 
    bool getLastCartesianState(std::vector<double>& position,
                                  std::vector<double>& quaternion,
                                  std::vector<double>& trans_vel,
                                  std::vector<double>& rot_vel,
                                  double& timestamp);

    /**
     * @brief Controls the robot by specifying joint velocities.
     * 
     * This function sets the velocity of each robot joint. The velocities are ramped up smoothly to avoid sudden jumps.
     * None of the velocities must exceed the thresholds defined in the GUI.
     * The dimension of the velocity and acceleration vectors corresponds to the robot's degrees of freedom (DOF)(6 or 7).
     * This function should be called cyclically.
     * 
     * @param velocity A vector containing the target angular velocities for each joint (in radians per second).
     * @param acceleration A vector containing the target angular accelerations for each joint (in radians per second squared). Max acceleration value is 5 radian per second squared.
     * @return int 0 if successful, or an error code if any of the parameters values exceed the allowed threshold or other errors occur.
    */
    int speedJ(std::vector<double>& velocity,
                std::vector<double>& acceleration);

    /**
     * @brief Controls the robot by specifying target joint positions, velocities, and accelerations.
     * 
     * This function sets the target joint positions, velocities, and accelerations for the robot. It is suggested to use an interpolator 
     * to avoid sudden jumps in the joint movement and not give far away targets. None of the velocities must exceed the thresholds defined in the GUI.
     * The interpolator can be used to change targets online, robot will adapt the trajectory while being within the constraints.
     * The dimension of the position, velocity, and acceleration vectors corresponds to the robot's degrees of freedom (DOF)(6 or 7).
     * This function should be called cyclically.
     * 
     * @param position A vector containing the target angular positions for each joint (in radians).
     * @param velocity A vector containing the target angular velocities for each joint (in radians per second).
     * @param acceleration A vector containing the target angular accelerations for each joint (in radians per second squared). Max acceleration value is 5 radian per second squared.
     * @return int 0 if successful, or an error code if the parameters exceed the allowed threshold or other errors occur.
    */
    int servoJ(std::vector<double>& position, std::vector<double>& velocity,
                   std::vector<double>& acceleration);

    /**
     * @brief Controls the robot by specifying target Cartesian positions, velocities, accelerations, and proportional gain.
     * 
     * This function sets the target Cartesian positions, velocities, accelerations, and a proportional gain controller for 
     * the robot. It controls the robot's Tool Center Point (TCP) in Cartesian space. None of the velocities must exceed the thresholds defined in the GUI. 
     * It is suggested to use an interpolator to avoid sudden jumps in the robot's movement.
     * The interpolator can be used to change targets online, robot will adapt the trajectory while being within the constraints.
     * 
     * This function should be called cyclically.
     * 
     * @param position A vector containing the target Cartesian positions of length 7 (translation (in m/s) and orientation) (x, y, z, qw, qx, qy, qz).
     * @param velocity A vector containing the target Cartesian velocities  of length 6 (translation (in m/s) and rotational (radian/s)) (x_dot, y_dot, z_dot, omega_x, omega_y, omega_z).
     * @param acceleration A vector containing the target Cartesian acceleration  of length 6 (translation (in m/s^2) and rotational (radian/s^2)) (x_ddot, y_ddot, z_ddot, alpha_x, alpha_y, alpha_z).
     * @param proportional_gain A scalar representing the proportional gain for the control loop. Proportional gain is between [0.2, 100].
     * @return int 0 if successful, or an error code if the parameters exceed the allowed threshold or other errors occur.
    */
    int servoX(std::vector<double>& position, std::vector<double>& velocity,
                   std::vector<double>& acceleration, double&
                   proportional_gain);

        
    /**
     * @brief Sends a cartesian velocity-only command and acceleration command to the robot
     * @param velocity target cartesian velocities, i.e. x_dot, y_dot, z_dot, omega_x, omega_y, omega_z
     * @param acceleration taget cartesian acceleration, i.e. x_dot_dot, y_dot_dot, z_dot_dot, alpha_x, alpha_y, alpha_z
     * @return feedback on execution, success, and possible error or timeout
    */
    int speedX(std::vector<double>& velocity,
                std::vector<double>& acceleration);

    /**
     * @brief Run Cartesian motion/ServoX with inbuilt interpolator to move the robot between current position and final target. No need for interpolator to be called on client side.
     * The program should not terminate after calling this function, either sleep can be added or some other process can be run. Please see examples for more information.
     * Function can be called multiple times to change target during the motion. 
     * 
     * @param position A vector containing the target Cartesian positions (x, y, z in meters, qw, qx, qy, qz).
     * @param velocity A vector containing the maximum Cartesian velocities that is to be reached during motion with x_dot, y_dot, z_dot, omega_x, omega_y, omega_z
     * @param acceleration A vector containing the maximum Cartesian acceleration that is to be reached during motion with x_ddot, y_ddot, z_ddot, alpha_x, alpha_y, alpha_z
     * @return int 0 if successful, or an error code if the velocities exceed the allowed threshold or other errors occur.
     */
    int moveLinearOnline(std::vector<double> &position, std::vector<double> &velocity, std::vector<double> &acceleration);

    /**
     * @brief Stops movelinearonline motion if its running.
     * 
     * @return true Stop command is successful
     * @return false Stop command is unsuccessful
     */
    bool stopMoveLinearOnline();

    /**
     * @brief Get the Forward Kinematics pose of a set of joint angles
     * 
     * @param request Set of joint angles(in radians) with length equal to degree of freedom
     * @param feedback Resulting pose sent through reference
     * @return true forward kinematics call successful
     * @return false forward kinematics call not successful
     */
    bool getForwardKinematics(std::vector<double>& request, std::vector<double>& feedback);
    
    /**
     * @brief Get the Inverse Kinematics (set of joint angles) for a specific pose. 
     * 
     * @param request Requested pose (X,Y,Z,qw,qx,qy,qz) (translation in meters)
     * @param feedback Resulting set of joint angles sent through reference
     * @return true inverse kinematics call successful
     * @return false inverse kinematics call not successful
     */
    bool getInverseKinematics(std::vector<double>& request, std::vector<double>& feedback);

    /**
     * @brief Get the Joint Limits (position and velocity) of the robot set through GUI.
     * 
     * @param limits The first elements are positive position limits for each joint (in radians), next elements are negative position limits for each joint (in radians),
                    next elements are positive velocity limits for each joint (in radians/second) and last set of elements are negative velocity limits for each joint (in radians/second).
     * @return true call is successful
     * @return false call is not successful
     */
    bool getCurrentJointLimits(std::vector<double>& limits);

    /**
     * @brief Get the Cartesian Limits (position and velocity) of the robot end effector set through GUI.
     * 
    * @param limits The first three elements are positive X,Y,Z position limits (in meters), next 3 elements are negative X,Y,Z position limits (in meters), next element is translation velocity (in meters/second), next element is rotational velocity (in radians/second). 
     * @return true call is successful 
     * @return false call is not successful 
     */
    bool getCurrentCartesianLimits(std::vector<double>& limits);


    /**
     * @brief Get the external wrench coming from force torque sensor connected to flange of the Robot
     * @param external_wrench The first three elements contains Forces i.e. Fx, Fy, Fz and the next 3 elements contain Moments, i.e. Mx, My, Mz
     * @return true call is successful 
     * @return false call is not successful 
     */
    bool getExternalWrench(std::vector<double>& external_wrench);

    /**
     * @brief Get the Trajectory Scaling Factor due to safety and limit constraints
     * 
     * @return double scaling factor between 0 and 1
     */
    double getTrajectoryScalingFactor();

    /**
     * @brief Get the Error Code due to error on the robot
     * 
     * @return int error code
     */
    int getErrorCode();

   private:
    class Client;
    std::unique_ptr<Client> p_client_;
};
}  // namespace neura

#endif  // NRTI_ROBOT_HPP
