#ifndef DDS_WRAPPER_HPP
#define DDS_WRAPPER_HPP

#include <neura_dds_utils/traces.hpp>

#include "participant.hpp"
#include "publisher.hpp"
#include "subscriber.hpp"

#define SERVER_DEFAULT_DOMAIN_ID 201        // some random number used for only server/client communication 

#endif