#ifndef DDS_CLIENT_DATAREADER_HPP
#define DDS_CLIENT_DATAREADER_HPP

#include <fastdds/dds/domain/DomainParticipant.hpp>
#include <fastdds/dds/subscriber/DataReader.hpp>
#include <fastdds/dds/subscriber/DataReaderListener.hpp>
#include <fastdds/dds/subscriber/Subscriber.hpp>
#include <fastdds/dds/subscriber/qos/DataReaderQos.hpp>
#include <fastdds/dds/topic/qos/TopicQos.hpp>
#include <neura_dds_utils/traces.hpp>

using namespace eprosima::fastdds::dds;

namespace neura_dds_wrapper
{
struct QoSConfig
{
    TopicQos topic;
    DataReaderQos reader;
};

template <typename TT>  // TS = TypeSupport, TT = TopicType (see idl file)
class DDSDataReaderListener : public DataReaderListener
{
   private:
    std::function<void(const TT&)> callback_;
    TT response_;

   public:
    DDSDataReaderListener(std::function<void(const TT&)> callback);
    ~DDSDataReaderListener();
    void on_data_available(DataReader* p_reader) override;
    void on_subscription_matched(
        DataReader* reader, const SubscriptionMatchedStatus& info) override;
    void on_sample_rejected(
        DataReader* reader,
        const eprosima::fastrtps::SampleRejectedStatus& info) override;
    void on_sample_lost(DataReader* reader, const SampleLostStatus& info) override;
};

class DDSDataReaderFactory
{
   private:
    DomainParticipant* p_participant_;
    Subscriber* p_subscriber_;
    QoSConfig qos_config_;

   public:
    DDSDataReaderFactory(DomainParticipant* pParticipant);
    ~DDSDataReaderFactory();
    template <typename TopicDescriptionType, typename TypeSupportType>
    DataReader* createDataReader(
        const std::string& topicName,
        DDSDataReaderListener<TopicDescriptionType>* pListener);
    void deleteDataReader(DataReader* data_reader);
};

template <typename TT>
DDSDataReaderListener<TT>::DDSDataReaderListener(
    std::function<void(const TT&)> callback)
    : callback_(callback) /*TODO, response_(nullptr)*/
{
}

template <typename TT>
DDSDataReaderListener<TT>::~DDSDataReaderListener()
{
}

template <typename TT>
void DDSDataReaderListener<TT>::on_data_available(DataReader* p_reader)
{
    TRACE(COMM, "on_data_available()");
    SampleInfo info;
    if (p_reader->take_next_sample(&response_, &info) ==
        ReturnCode_t::RETCODE_OK)
    {
        if (info.valid_data)
        {
            TRACE(COMM, "valid data received");
            if (callback_ != nullptr)
            {
                callback_(response_);
            }
        }
        else
        {
            TRACE(ERROR, "invalid data received");
        }
    }
}

template <typename TT>
void DDSDataReaderListener<TT>::on_subscription_matched(
    DataReader* reader, const SubscriptionMatchedStatus& info)
{
    static_cast<void>(reader);
    if (info.current_count_change == 1)
    {
        TRACE(SUBSCRIBER,  "Matched a remote DataWriter for " << reader->get_topicdescription()->get_name());
    }
    else if (info.current_count_change == -1)
    {
        TRACE(SUBSCRIBER,  "Unmatched a remote DataWriter for" << reader->get_topicdescription()->get_name());
    }
}

template <typename TT>
void DDSDataReaderListener<TT>::on_sample_rejected(
    DataReader* reader, const eprosima::fastrtps::SampleRejectedStatus& info)
{
    static_cast<void>(reader);
    static_cast<void>(info);
    TRACE(SUBSCRIBER,  "A received data sample was rejected" << std::endl);
}

template <typename TT>
void DDSDataReaderListener<TT>::on_sample_lost(DataReader* reader,
                                               const SampleLostStatus& info)
{
    static_cast<void>(reader);
    static_cast<void>(info);
    // TRACE(SUBSCRIBER,  "A data sample was lost and will not be received" << std::endl);
}

template <typename TopicDescriptionType, typename TypeSupportType>
DataReader* DDSDataReaderFactory::createDataReader(
    const std::string& topicName,
    DDSDataReaderListener<TopicDescriptionType>* pListener)
{
    TypeSupport type = TypeSupport(new TypeSupportType());
    // DomainParticipant* p_participant = const_cast<DomainParticipant*>
    // (p_subscriber_ ->get_participant()); // This must be done bc
    // registesr_type(participant), does not allow const participant object

    ReturnCode_t ret = p_participant_->register_type(type);

    if (ret != ReturnCode_t::RETCODE_OK)
    {
        throw std::runtime_error(
            "Type could not be registered, name=" + type.get_type_name() +
            ", reason=" + std::to_string(ret()));
    }
    else
    {
        TRACE(SUBSCRIBER, "Registered topic with type=" + type.get_type_name())
    }
    Topic* p_topic = p_participant_->create_topic(
        topicName, type.get_type_name(), qos_config_.topic);

    if (p_topic == nullptr)
    {
        throw std::runtime_error("Topic object could not be created for " +
                                 topicName);
    }

    DataReader* p_reader = p_subscriber_->create_datareader(
        p_topic, qos_config_.reader, pListener);

    if (p_reader == nullptr)
    {
        throw std::runtime_error("Reader object could not be created for " +
                                 topicName);
    }

    TRACE(SUBSCRIBER,
          "Created Datareader which implicitly listens to registered topic=" +
              topicName)

    return p_reader;
}
}  // namespace neura_dds_wrapper

#endif
